#!/usr/bin/env python
"""
=============================================================================
 chrome-devtools-perf-mcp — a minimal Chrome DevTools (CDP) MCP server
=============================================================================
 Speaks the Model Context Protocol over stdio. Loads a page in a real browser
 (system Chrome/Edge via Playwright) and reports what the browser ACTUALLY
 experienced — live FCP/LCP/CLS, timing, request waterfall, console errors, a
 screenshot, and a raw CDP Performance.getMetrics snapshot. Every result is
 readable text + structured JSON, and every metric is explained for a newcomer.

 This is the "field/live" companion to lighthouse-perf-mcp (the "lab" view).

 Tools
   capture_metrics(url, device?, waterfall?, screenshot?, cdp_metrics?)
   get_web_vitals(url, device?)        quick FCP / LCP / CLS
   list_requests(url, device?)         the network waterfall (biggest first)
   take_screenshot(url, device?)       a screenshot of the page
   explain_metric(metric)              teach one metric (no page load)

 Register it in your MCP client:
   { "mcpServers": { "chrome-devtools-perf": {
       "command": "python",
       "args": ["C:/.../chrome-devtools-mcp/server.py"] } } }

 Requires: pip install -r requirements.txt  (Playwright + a system browser).
=============================================================================
"""
import sys
from urllib.parse import urlparse

# The protocol stream + summaries contain non-ASCII (emoji, ≤). Force UTF-8 so a
# Windows console locale (cp1252) can't raise UnicodeEncodeError mid-message.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.utilities.types import Image

from engine import METRICS, capture, explain_metric as _explain_metric

mcp = FastMCP("chrome-devtools-perf-mcp")


def _short_url(u):
    try:
        x = urlparse(u)
        return (x.path.rstrip("/").split("/")[-1] or x.hostname or u)
    except Exception:
        return u


@mcp.tool()
async def capture_metrics(url: str, device: str = "desktop", waterfall: bool = False,
                          screenshot: bool = False, cdp_metrics: bool = False) -> dict:
    """Load a URL in a real browser and report what it actually experienced: FCP,
    LCP, CLS, TTFB, DOM Content Loaded, Page Load, request count, bytes
    transferred, and console errors — each explained in plain English.

    Args:
        url: The URL to measure, including https://
        device: Device to emulate — "desktop" or "mobile".
        waterfall: Include the network request waterfall.
        screenshot: Include a screenshot (data URL) in the structured result.
        cdp_metrics: Include the raw CDP Performance.getMetrics snapshot.
    """
    r = await capture(url, device=device, waterfall=waterfall, screenshot=screenshot, cdp_metrics=cdp_metrics)
    lines = [f"Live performance for {r['finalUrl']} ({device})", ""]
    for key, info in METRICS.items():
        m = r["metrics"][key]
        v = "n/a" if m["value"] is None else (f"{m['value']} ms" if info["unit"] == "ms" else f"{m['value']}")
        lines.append(f"  {m['emoji']} {info['label']} ({info['name']}): {v} → {m['rating']}")
    lines += ["", f"Requests: {r['totalRequests'] if r['totalRequests'] is not None else '—'} · "
              f"Transferred: {r['transferKb'] if r['transferKb'] is not None else '—'} KB · "
              f"Console errors: {r['consoleErrors']}"]
    return {"summary": "\n".join(lines), **r}


@mcp.tool()
async def get_web_vitals(url: str, device: str = "desktop") -> dict:
    """Return just the three Core Web Vitals (FCP, LCP, CLS) a real browser
    observed for a URL.

    Args:
        url: The URL to measure.
        device: Device to emulate — "desktop" or "mobile".
    """
    r = await capture(url, device=device)
    m = r["metrics"]
    text = (f"{r['finalUrl']}\n"
            f"{m['fcp']['emoji']} FCP: {m['fcp']['value'] if m['fcp']['value'] is not None else 'n/a'} ms\n"
            f"{m['lcp']['emoji']} LCP: {m['lcp']['value'] if m['lcp']['value'] is not None else 'n/a'} ms\n"
            f"{m['cls']['emoji']} CLS: {m['cls']['value'] if m['cls']['value'] is not None else 'n/a'}")
    return {"summary": text, "url": r["finalUrl"], "fcp": m["fcp"], "lcp": m["lcp"], "cls": m["cls"]}


@mcp.tool()
async def list_requests(url: str, device: str = "desktop") -> dict:
    """Load a URL and list its network requests (biggest first): type, resource,
    size, and duration.

    Args:
        url: The URL to measure.
        device: Device to emulate — "desktop" or "mobile".
    """
    r = await capture(url, device=device, waterfall=True)
    rows = []
    for res in r["resources"][:20]:
        size = f"{round(res['size'] / 1024)} KB" if res.get("size") else "—"
        rows.append(f"  {(res.get('type') or 'doc'):<8} {size:<8} {str(res['duration']) + ' ms':<8} {_short_url(res['name'])}")
    text = (f"{r['totalRequests'] if r['totalRequests'] is not None else '—'} requests · "
            f"{r['transferKb'] if r['transferKb'] is not None else '—'} KB transferred\n\n"
            f"TYPE     SIZE     TIME     RESOURCE\n" + "\n".join(rows))
    return {"summary": text, "url": r["finalUrl"], "totalRequests": r["totalRequests"],
            "transferKb": r["transferKb"], "resources": r["resources"]}


@mcp.tool()
async def take_screenshot(url: str, device: str = "desktop") -> Image:
    """Load a URL in a real browser and return a screenshot.

    Args:
        url: The URL to capture.
        device: Device to emulate — "desktop" or "mobile".
    """
    r = await capture(url, device=device, screenshot=True)
    if not r["screenshot"]:
        raise RuntimeError("Screenshot could not be captured.")
    raw = base64_to_bytes(r["screenshot"])
    return Image(data=raw, format="jpeg")


@mcp.tool()
def explain_metric(metric: str) -> dict:
    """Teach a single live metric (fcp, lcp, cls, ttfb, domContentLoaded, load):
    what it is, why it matters, Good/Poor thresholds. No page is loaded.

    Args:
        metric: Metric key — fcp, lcp, cls, ttfb, domContentLoaded, or load.
    """
    e = _explain_metric(metric)
    if not e:
        raise ValueError(f"Unknown metric: {metric}. Valid: {', '.join(METRICS)}")
    return {"summary": f"{e['label']} — {e['name']}\n\nWhat it is: {e['what']}\nWhy it matters: {e['why']}\n{e['rule']}", **e}


def base64_to_bytes(data_url):
    import base64
    return base64.b64decode(data_url.split(",", 1)[1])


if __name__ == "__main__":
    # Start on stdio (FastMCP's default transport). Logs go to stderr so they
    # never corrupt the protocol stream on stdout.
    mcp.run()
