# lighthouse-perf-mcp

A small **MCP server** that wraps Google Lighthouse to measure **single-user web
performance** and explain every number in plain English — built so a brand-new
user can understand the concepts, not just see scores.

It speaks the **Model Context Protocol** over stdio, so any MCP client (Claude
Code in VS Code, Claude Desktop, etc.) can call its tools. Every result comes
back as **readable text** (to show in chat) **and structured JSON** (so the
agent can reason over the numbers).

## Tools

| Tool | What it does |
|------|--------------|
| `run_audit(url, device?, throttling?)` | Full audit: every metric (LCP, FCP, CLS, TBT, SI, TTI) + category scores, each explained, with an overall verdict and top opportunities. |
| `get_performance_score(url, device?)` | Quick check: just the 0–100 performance score + a one-line verdict. |
| `explain_metric(metric)` | Teach one metric (no audit run): what it is, why it matters, Good/Poor thresholds. `metric` ∈ lcp, fcp, cls, tbt, si, tti. |
| `compare_urls(urlA, urlB, device?)` | Audit two URLs and show a side-by-side of scores and metrics. |

`device` is `desktop` (default) or `mobile`. `throttling` (default `false`)
applies simulated mobile-network conditions.

## The metrics, in plain English

- **LCP** — when the biggest thing on screen finishes loading (page *looks* ready). Good ≤ 2.5 s.
- **FCP** — when the first text/image appears. Good ≤ 1.8 s.
- **CLS** — how much the page jumps while loading. Good ≤ 0.1 (0 = nothing moved).
- **TBT** — how long the page was frozen and ignored clicks. Good ≤ 200 ms.
- **SI** — how quickly the page visually fills in. Good ≤ 3.4 s.
- **TTI** — when every button reliably responds. Good ≤ 3.8 s.

Bands everywhere: 🟢 Good (90–100) · 🟡 Needs improvement (50–89) · 🔴 Poor (0–49).

## Install

```powershell
cd lighthouse-mcp
py -m pip install -r requirements.txt   # the `mcp` Python SDK
npm install -g lighthouse               # the Lighthouse CLI (the one Node dep)
```

This server is **Python** (FastMCP). Lighthouse has no Python port, so it calls
the global `lighthouse` CLI via subprocess — that CLI must be on your PATH, and
Chrome/Chromium must be installed (Lighthouse drives it).

## Register in your MCP client

Add this to your MCP settings (adjust the absolute paths):

```json
{
  "mcpServers": {
    "lighthouse-perf": {
      "command": "C:/Users/2431329/AppData/Local/Programs/Python/Python313/python.exe",
      "args": ["C:/Users/2431329/OneDrive - Cognizant/Desktop/Har agent/lighthouse-mcp/server.py"]
    }
  }
}
```

Then in chat you can say things like *“run a Lighthouse audit on example.com”*
and the agent will call `run_audit`.

## Quick manual check

```powershell
py server.py    # waits for MCP JSON-RPC messages on stdin
```

(The server talks JSON-RPC over stdin/stdout; logs go to stderr so they never
corrupt the protocol stream.)

## Files

```
lighthouse-mcp/
├── server.py          MCP server (FastMCP): registers the 4 tools, text + JSON
├── engine.py          Lighthouse runner (CLI subprocess) + metric dictionary
├── requirements.txt
└── README.md
```

## How this fits the bigger flow

This is the **Lighthouse MCP** piece. Alongside it:
- Your **Playwright MCP** drives the browser through a journey.
- A **Chrome DevTools MCP** (coming next) adds live CDP traces.

An agent can call all three and show the results together.
