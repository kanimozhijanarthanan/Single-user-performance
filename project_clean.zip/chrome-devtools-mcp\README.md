# chrome-devtools-perf-mcp

A small **MCP server** that loads a page in a **real browser** and reports what
the browser *actually experienced* — live Core Web Vitals, timing, the network
waterfall, console errors, and a screenshot. Built so a brand-new user can
understand each number.

This is the **live / field** companion to `lighthouse-perf-mcp` (the **lab**
view). Together with your **Playwright MCP**, they cover the full picture for a
single visitor.

> Note: this is our own minimal CDP server. Google also publishes a full-featured
> `chrome-devtools-mcp` (45+ tools) you can run with `npx chrome-devtools-mcp@latest`.
> This one is intentionally small, self-contained, and concept-explaining.

## Tools

| Tool | What it does |
|------|--------------|
| `capture_metrics(url, device?, waterfall?, screenshot?, cdpMetrics?)` | Full live capture: FCP, LCP, CLS, TTFB, DCL, Load + requests/bytes/console errors, each explained. |
| `get_web_vitals(url, device?)` | Quick check: just FCP / LCP / CLS. |
| `list_requests(url, device?)` | The network waterfall (biggest first): type, size, duration. |
| `take_screenshot(url, device?)` | A screenshot of the page (returned as an image). |
| `explain_metric(metric)` | Teach one metric (no page load). `metric` ∈ fcp, lcp, cls, ttfb, domContentLoaded, load. |

`device` is `desktop` (default) or `mobile`.

## The metrics, in plain English

- **FCP** — when the first text/image appeared (page is working). Good ≤ 1.8 s.
- **LCP** — when the biggest element finished painting (page looks ready). Good ≤ 2.5 s.
- **CLS** — how much the page jumped while loading. Good ≤ 0.1 (0 = nothing moved).
- **TTFB** — how long the server took to send the first byte. Good ≤ 0.8 s.
- **DCL** — when the DOM was parsed and ready. 
- **Load** — when everything finished loading.

Bands: 🟢 Good · 🟡 Needs improvement · 🔴 Poor.

## How it works

Uses **Playwright** to drive a browser **already installed on your machine**
(Chrome → Edge → bundled chromium, in that order — because corporate networks
often block Playwright's own browser download). Inside the page it reads
`PerformanceObserver` (FCP/LCP/CLS), Navigation Timing (TTFB/DCL/Load), and
Resource Timing (the waterfall). With `cdpMetrics: true` it also pulls a raw
`Performance.getMetrics` snapshot over a CDP session.

## Install

```powershell
cd chrome-devtools-mcp
py -m pip install -r requirements.txt   # the `mcp` Python SDK + playwright
py -m playwright install chromium       # only if no system Chrome/Edge
```

This server is **Python** (FastMCP + Playwright's async API). Chrome or Edge
must be installed.

## Register in your MCP client

```json
{
  "mcpServers": {
    "chrome-devtools-perf": {
      "command": "C:/Users/2431329/AppData/Local/Programs/Python/Python313/python.exe",
      "args": ["C:/Users/2431329/OneDrive - Cognizant/Desktop/Har agent/chrome-devtools-mcp/server.py"]
    }
  }
}
```

Then in chat: *“capture live metrics for example.com”* → the agent calls `capture_metrics`.

> Note: the `cdpMetrics` tool argument is `cdp_metrics` in the Python server.

## Files

```
chrome-devtools-mcp/
├── server.py          MCP server (FastMCP): registers the 5 tools, text + JSON
├── engine.py          CDP capture (PerformanceObserver + timing + CDP session)
├── requirements.txt
└── README.md
```

## The bigger flow

Three MCP servers, one agent:
- 🎭 **Playwright MCP** — drives the browser through a journey (you already have it).
- 🔦 **lighthouse-perf-mcp** — lab score + opportunities.
- 🛠️ **chrome-devtools-perf-mcp** (this) — live field metrics + waterfall + screenshot.

Wiring all three into one MCP config is the next step.
