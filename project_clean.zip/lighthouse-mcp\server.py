#!/usr/bin/env python
"""
=============================================================================
 lighthouse-perf-mcp — a Lighthouse MCP server for single-user performance
=============================================================================
 Speaks the Model Context Protocol over stdio, so an MCP client (Claude Code in
 VS Code, Claude Desktop, etc.) can call its tools. Every result is returned
 BOTH as readable text (for the chat) and structured JSON (so the agent can
 reason over the numbers).

 Tools
   run_audit(url, device?, throttling?)  full audit, every metric explained
   get_performance_score(url, device?)   quick 0-100 score + one-line verdict
   explain_metric(metric)                teach a metric (no audit run)
   compare_urls(urlA, urlB, device?)     side-by-side of two pages

 Register it in your MCP client, e.g.:
   { "mcpServers": { "lighthouse-perf": {
       "command": "python",
       "args": ["C:/.../lighthouse-mcp/server.py"] } } }

 Requires: pip install -r requirements.txt  AND  npm i -g lighthouse (the CLI).
=============================================================================
"""
import asyncio
import sys

# The protocol stream + summaries contain non-ASCII (emoji, ≤). Force UTF-8 so a
# Windows console locale (cp1252) can't raise UnicodeEncodeError mid-message.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass

from mcp.server.fastmcp import FastMCP

from engine import METRICS, explain_metric as _explain_metric, run_audit as _run_audit

mcp = FastMCP("lighthouse-perf-mcp")


# ---------------------------------------------------------------------------
#  Text formatter — turn the structured result into the readable summary the
#  agent shows in chat (mirrors the look of a Lighthouse report).
# ---------------------------------------------------------------------------
def _fmt_audit(r):
    lines = [f"Lighthouse audit for {r['finalUrl']}", "",
             f"Performance: {r['performanceScore'] if r['performanceScore'] is not None else '—'}/100 — {r['verdict']}",
             "", "Core metrics:"]
    for m in r["metrics"]:
        score = "" if m["score"] is None else f" ({m['score']}/100)"
        lines.append(f"  {m['emoji']} {m['label']} — {m['name']}: {m['value']}{score} → {m['rating']}")
    lines += ["", "Other category scores:"]
    for c in [c for c in r["categories"] if c["key"] != "performance"]:
        lines.append(f"  {c['emoji']} {c['label']}: {c['score']}/100")
    if r["opportunities"]:
        lines += ["", "Top opportunities (estimated time saved):"]
        for o in r["opportunities"]:
            lines.append(f"  • {o['title']} — save ~{o['saveMs']} ms")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
#  MCP tools. FastMCP turns type hints + the docstring into the input schema;
#  returning a dict gives the client structured content alongside the text.
# ---------------------------------------------------------------------------
@mcp.tool()
async def run_audit(url: str, device: str = "desktop", throttling: bool = False) -> dict:
    """Audit a URL and return every performance metric (LCP, FCP, CLS, TBT, SI,
    TTI) and category score, each explained in plain English, plus an overall
    verdict and top opportunities.

    Args:
        url: The URL to audit, including https://
        device: Device to emulate — "desktop" or "mobile".
        throttling: Apply simulated mobile-network throttling.
    """
    r = await _run_audit(url, device=device, throttling=throttling)
    return {"summary": _fmt_audit(r), **r}


@mcp.tool()
async def get_performance_score(url: str, device: str = "desktop") -> dict:
    """Return just the 0–100 performance score and a one-line plain-English
    verdict for a URL.

    Args:
        url: The URL to audit.
        device: Device to emulate — "desktop" or "mobile".
    """
    r = await _run_audit(url, device=device)
    return {
        "summary": f"{r['finalUrl']}\nPerformance: {r['performanceScore'] if r['performanceScore'] is not None else '—'}/100 — {r['verdict']}",
        "url": r["finalUrl"], "performanceScore": r["performanceScore"], "verdict": r["verdict"],
    }


@mcp.tool()
def explain_metric(metric: str) -> dict:
    """Teach a single metric (lcp, fcp, cls, tbt, si, or tti): what it is, why it
    matters, and the Good/Poor thresholds. No audit is run.

    Args:
        metric: Metric key — lcp, fcp, cls, tbt, si, or tti.
    """
    e = _explain_metric(metric)
    if not e:
        raise ValueError(f"Unknown metric: {metric}. Valid: {', '.join(METRICS)}")
    return {
        "summary": f"{e['label']} — {e['name']}\n\nWhat it is: {e['what']}\nWhy it matters: {e['why']}\n{e['rule']}",
        **e,
    }


@mcp.tool()
async def compare_urls(urlA: str, urlB: str, device: str = "desktop") -> dict:
    """Audit two URLs and return a side-by-side comparison of their performance
    scores and core metrics.

    Args:
        urlA: First URL.
        urlB: Second URL.
        device: Device to emulate — "desktop" or "mobile".
    """
    a, b = await asyncio.gather(_run_audit(urlA, device=device), _run_audit(urlB, device=device))
    sa = a["performanceScore"] or 0
    sb = b["performanceScore"] or 0
    winner = "Tie" if sa == sb else ("A is faster" if sa > sb else "B is faster")
    lines = [f"Comparison ({device}):", "",
             f"A: {a['finalUrl']} — Performance {a['performanceScore'] if a['performanceScore'] is not None else '—'}/100",
             f"B: {b['finalUrl']} — Performance {b['performanceScore'] if b['performanceScore'] is not None else '—'}/100",
             "", "Metric            A            B"]
    b_by_key = {m["key"]: m for m in b["metrics"]}
    for ma in a["metrics"]:
        mb = b_by_key.get(ma["key"])
        lines.append(f"{ma['label']:<6} {str(ma['value']):<12} {str(mb['value'] if mb else '—')}")
    lines += ["", f"Verdict: {winner}."]
    return {"summary": "\n".join(lines), "device": device, "winner": winner, "a": a, "b": b}


if __name__ == "__main__":
    # Start on stdio (FastMCP's default transport). Logs go to stderr so they
    # never corrupt the protocol stream on stdout.
    mcp.run()
