"""
engine.py — Chrome DevTools (CDP) capture core for the MCP server.

Loads a page in a real browser (system Chrome/Edge via Playwright's ASYNC API)
and reads what the browser actually experienced: FCP / LCP / CLS via
PerformanceObserver, Navigation + Resource Timing, console errors, a screenshot,
and a raw CDP Performance.getMetrics snapshot. Pure measurement — no MCP code.
"""
import base64

from playwright.async_api import async_playwright

# ---------------------------------------------------------------------------
#  METRIC DICTIONARY — plain-English teaching content for a brand-new user.
#  These are the LIVE numbers a real browser saw (field-style), as opposed to
#  Lighthouse's lab score. Thresholds are Google's Core Web Vitals cutoffs.
# ---------------------------------------------------------------------------
METRICS = {
    "fcp":  {"label": "FCP",  "name": "First Contentful Paint",
             "what": "When the first text or image actually appeared in this browser.",
             "why": "Proof to the visitor that the page is working, not frozen.", "good": 1800, "poor": 3000, "unit": "ms"},
    "lcp":  {"label": "LCP",  "name": "Largest Contentful Paint",
             "what": "When the biggest element finished painting — the page looked ready.",
             "why": 'The headline "is it loaded yet" moment for a real visitor.', "good": 2500, "poor": 4000, "unit": "ms"},
    "cls":  {"label": "CLS",  "name": "Cumulative Layout Shift",
             "what": "How much things jumped around while the page settled.",
             "why": "Jumpiness causes mis-clicks and feels low quality. 0 = nothing moved.", "good": 0.1, "poor": 0.25, "unit": ""},
    "ttfb": {"label": "TTFB", "name": "Time to First Byte",
             "what": "How long the server took to send the first byte.",
             "why": "A slow server delays everything that follows.", "good": 800, "poor": 1800, "unit": "ms"},
    "domContentLoaded": {"label": "DCL", "name": "DOM Content Loaded",
             "what": "When the HTML was parsed and the DOM was ready.",
             "why": "Scripts that wait for the DOM can start now.", "good": 2000, "poor": 4000, "unit": "ms"},
    "load": {"label": "Load", "name": "Page Load",
             "what": "When everything (images, styles, scripts) finished loading.",
             "why": 'The classic "page fully loaded" wall-clock time.', "good": 3400, "poor": 5800, "unit": "ms"},
}


def band(key, value):
    """value -> band level (lower is better for every CDP metric here)."""
    m = METRICS.get(key)
    if not m or value is None:
        return {"level": "na", "emoji": "⚪", "text": "No data"}
    if value <= m["good"]:
        return {"level": "good", "emoji": "🟢", "text": "Good"}
    if value <= m["poor"]:
        return {"level": "average", "emoji": "🟡", "text": "Needs improvement"}
    return {"level": "poor", "emoji": "🔴", "text": "Poor"}


def explain_metric(key):
    m = METRICS.get(key)
    if not m:
        return None

    def fmt(v):
        return f"{v} ms" if m["unit"] == "ms" else f"{v}"

    return {
        "key": key, "label": m["label"], "name": m["name"], "what": m["what"], "why": m["why"],
        "rule": f"Good when ≤ {fmt(m['good'])}; Poor when ≥ {fmt(m['poor'])}.",
    }


_MEASURE_JS = """() => {
  const out = { fcp: null, lcp: null, cls: 0, ttfb: null, domContentLoaded: null, load: null, resources: [], transferBytes: 0, totalRequests: null };
  for (const e of performance.getEntriesByType('paint')) {
    if (e.name === 'first-contentful-paint') out.fcp = Math.round(e.startTime);
  }
  const nav = performance.getEntriesByType('navigation')[0];
  if (nav) {
    out.ttfb = Math.round(nav.responseStart);
    out.domContentLoaded = Math.round(nav.domContentLoadedEventEnd);
    out.load = Math.round(nav.loadEventEnd || nav.duration);
  }
  const lcps = performance.getEntriesByType('largest-contentful-paint');
  if (lcps.length) out.lcp = Math.round(lcps[lcps.length - 1].startTime);
  let cls = 0;
  for (const e of performance.getEntriesByType('layout-shift')) { if (!e.hadRecentInput) cls += e.value; }
  out.cls = Math.round(cls * 1000) / 1000;
  const res = performance.getEntriesByType('resource').map(r => ({
    name: r.name, type: r.initiatorType, duration: Math.round(r.duration),
    size: Math.round(r.transferSize || 0), start: Math.round(r.startTime),
  }));
  out.resources = res.sort((a, b) => b.size - a.size).slice(0, 30);
  out.transferBytes = res.reduce((a, r) => a + r.size, 0);
  out.totalRequests = res.length + 1;
  return out;
}"""


async def _launch_browser(pw):
    """Launch a browser already on the machine (Playwright's own download is
    often blocked on corporate networks): try Chrome, then Edge, then chromium."""
    last_err = None
    for opts in ({"channel": "chrome"}, {"channel": "msedge"}, {}):
        try:
            return await pw.chromium.launch(headless=True, **opts)
        except Exception as err:
            last_err = err
    raise last_err or RuntimeError(
        "No usable browser. Install Chrome/Edge, or run: python -m playwright install chromium"
    )


# ---------------------------------------------------------------------------
#  Capture live metrics for a URL. Optionally include the resource waterfall,
#  a screenshot, and a raw CDP Performance.getMetrics snapshot.
# ---------------------------------------------------------------------------
async def capture(url, device="desktop", screenshot=False, waterfall=False, cdp_metrics=False):
    async with async_playwright() as pw:
        browser = await _launch_browser(pw)
        console_errors = []
        try:
            viewport = {"width": 412, "height": 823} if device == "mobile" else {"width": 1350, "height": 940}
            context = await browser.new_context(viewport=viewport)
            page = await context.new_page()
            page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: console_errors.append(str(e)))

            cdp_session = None
            if cdp_metrics:
                try:
                    cdp_session = await context.new_cdp_session(page)
                    await cdp_session.send("Performance.enable")
                except Exception:
                    cdp_session = None

            try:
                await page.goto(url, wait_until="load", timeout=60000)
            except Exception:
                pass
            await page.wait_for_timeout(1200)  # let late paints / layout shifts register

            try:
                data = await page.evaluate(_MEASURE_JS)
            except Exception:
                data = {}

            shot = None
            if screenshot:
                try:
                    png = await page.screenshot(type="jpeg", quality=55)
                    shot = "data:image/jpeg;base64," + base64.b64encode(png).decode("ascii")
                except Exception:
                    pass

            raw_cdp = None
            if cdp_session:
                try:
                    res = await cdp_session.send("Performance.getMetrics")
                    raw_cdp = {m["name"]: m["value"] for m in res.get("metrics", [])}
                except Exception:
                    pass

            metrics = {}
            for key in METRICS:
                value = data.get(key)
                b = band(key, value)
                metrics[key] = {"value": value, "level": b["level"], "emoji": b["emoji"], "rating": b["text"]}

            transfer_bytes = data.get("transferBytes") or 0
            return {
                "url": url,
                "finalUrl": page.url,
                "metrics": metrics,
                "totalRequests": data.get("totalRequests"),
                "transferKb": round(transfer_bytes / 1024) if transfer_bytes else None,
                "consoleErrors": len(console_errors),
                "consoleErrorSamples": console_errors[:5],
                "resources": (data.get("resources") or []) if waterfall else [],
                "screenshot": shot,
                "cdpRawMetrics": raw_cdp,
            }
        finally:
            try:
                await browser.close()
            except Exception:
                pass
