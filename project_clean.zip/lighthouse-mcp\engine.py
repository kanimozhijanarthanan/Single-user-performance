"""
engine.py — the Lighthouse measurement core for the MCP server.

Pure functions + one audit runner. No MCP/protocol code lives here, so it can be
tested on its own. server.py wraps these in MCP tools.

There is no Python Lighthouse library, so we shell out to the Lighthouse CLI
(`npm i -g lighthouse`) and parse its JSON report — the same approach AuditX. Performance Audit Agent's
server.py uses. The CLI is the only Node dependency.
"""
import asyncio
import json
import os
import shutil
import tempfile

# ---------------------------------------------------------------------------
#  METRIC DICTIONARY — plain-English teaching content for a brand-new user.
#  Each metric: what it is, why it matters, and the Good / Poor thresholds
#  (Google's official Core Web Vitals + Lighthouse cutoffs).
# ---------------------------------------------------------------------------
METRICS = {
    "lcp": {
        "label": "LCP", "name": "Largest Contentful Paint", "lhId": "largest-contentful-paint", "unit": "s",
        "what": "How long until the biggest thing on screen (usually the hero image or main headline) is fully shown.",
        "why": "This is the moment the page LOOKS ready to the visitor. It is the headline performance number.",
        "good": 2500, "poor": 4000,
    },
    "fcp": {
        "label": "FCP", "name": "First Contentful Paint", "lhId": "first-contentful-paint", "unit": "s",
        "what": "How long until the FIRST piece of content (any text or image) appears.",
        "why": "A blank screen feels broken. First paint is the visitor's first proof the page is working.",
        "good": 1800, "poor": 3000,
    },
    "cls": {
        "label": "CLS", "name": "Cumulative Layout Shift", "lhId": "cumulative-layout-shift", "unit": "",
        "what": "How much the page jumps around while it loads (a button moves just as you go to tap it).",
        "why": "Unexpected movement makes people mis-tap and feels low quality. 0 means nothing moved.",
        "good": 0.1, "poor": 0.25,
    },
    "tbt": {
        "label": "TBT", "name": "Total Blocking Time", "lhId": "total-blocking-time", "unit": "ms",
        "what": "How long the page was frozen and unable to respond to clicks while it was busy running code.",
        "why": "A page can LOOK ready but ignore your clicks. High TBT means a frustrating, unresponsive feel.",
        "good": 200, "poor": 600,
    },
    "si": {
        "label": "SI", "name": "Speed Index", "lhId": "speed-index", "unit": "s",
        "what": "How quickly the page visually fills in from blank to complete.",
        "why": 'Captures the overall "it loaded fast" feeling, not just one single moment.',
        "good": 3400, "poor": 5800,
    },
    "tti": {
        "label": "TTI", "name": "Time to Interactive", "lhId": "interactive", "unit": "s",
        "what": "How long until the page is fully usable — every button and link reliably responds.",
        "why": "This is when the visitor can actually start doing things, not just looking.",
        "good": 3800, "poor": 7300,
    },
}

CATEGORIES = ["performance", "accessibility", "best-practices", "seo"]


def band(score):
    """A 0..100 score (or 0..1 fraction) -> a simple band a newcomer understands."""
    if score is None:
        return {"level": "na", "emoji": "⚪", "text": "No data"}
    s = score * 100 if score <= 1 else score
    if s >= 90:
        return {"level": "good", "emoji": "🟢", "text": "Good"}
    if s >= 50:
        return {"level": "average", "emoji": "🟡", "text": "Needs improvement"}
    return {"level": "poor", "emoji": "🔴", "text": "Poor"}


def verdict(perf_score):
    """Plain-English verdict for the overall performance score."""
    if perf_score is None:
        return "We could not measure performance for this page."
    if perf_score >= 90:
        return "Fast for a single visitor. Most users will have a smooth experience."
    if perf_score >= 50:
        return "Okay, but has room to improve. Some users will notice waiting."
    return "Slow for a single visitor. Users are likely to wait noticeably and may leave."


def explain_metric(key):
    """The teaching payload for one metric (used by the explain_metric tool)."""
    m = METRICS.get(key)
    if not m:
        return None

    def fmt(v):
        if m["unit"] == "s":
            return f"{v / 1000:.1f} s"
        if m["unit"] == "ms":
            return f"{v} ms"
        return f"{v}"

    good_txt, poor_txt = fmt(m["good"]), fmt(m["poor"])
    return {
        "key": key, "label": m["label"], "name": m["name"],
        "what": m["what"], "why": m["why"],
        "goodThreshold": good_txt, "poorThreshold": poor_txt,
        "rule": f"Good when ≤ {good_txt}; Poor when ≥ {poor_txt}.",
    }


def _lighthouse_cli():
    return shutil.which("lighthouse") or shutil.which("lighthouse.cmd")


# ---------------------------------------------------------------------------
#  Run one Lighthouse audit and shape the result into clean, explained data.
# ---------------------------------------------------------------------------
async def run_audit(url, device="desktop", throttling=False):
    cli = _lighthouse_cli()
    if not cli:
        raise RuntimeError("Lighthouse CLI not found. Install it: npm i -g lighthouse")

    tmp = tempfile.mkdtemp(prefix="lh-mcp-")
    out_base = os.path.join(tmp, "report")  # CLI appends .report.json
    form_factor = "mobile" if device == "mobile" else "desktop"
    screen = (
        ["--screenEmulation.mobile", "--screenEmulation.width=412",
         "--screenEmulation.height=823", "--screenEmulation.deviceScaleFactor=1.75"]
        if device == "mobile"
        else ["--screenEmulation.disabled=false", "--screenEmulation.width=1350",
              "--screenEmulation.height=940", "--screenEmulation.deviceScaleFactor=1"]
    )
    args = [
        cli, url,
        f"--only-categories={','.join(CATEGORIES)}",
        f"--form-factor={form_factor}",
        "--output=json", f"--output-path={out_base}",
        "--quiet", "--chrome-flags=--headless --no-sandbox --disable-gpu",
    ] + screen
    if not throttling:
        # Finite "fast connection" values (not zero — all-zero makes Lighthouse's
        # estimator divide by zero in the byte-efficiency audits).
        args += [
            "--throttling-method=provided",
            "--throttling.rttMs=1", "--throttling.throughputKbps=100000",
            "--throttling.cpuSlowdownMultiplier=1", "--throttling.requestLatencyMs=1",
            "--throttling.downloadThroughputKbps=100000", "--throttling.uploadThroughputKbps=100000",
        ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=180)
        json_path = out_base + ".report.json"
        if proc.returncode != 0 and not os.path.exists(json_path):
            raise RuntimeError("Lighthouse failed: " + (stderr.decode(errors="ignore")[:300] if stderr else "unknown error"))
        if not os.path.exists(json_path):
            raise RuntimeError("Lighthouse returned no result")
        with open(json_path, "r", encoding="utf-8") as fh:
            lhr = json.load(fh)
        return shape_result(lhr, url)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def shape_result(lhr, url):
    audits = lhr.get("audits", {})
    metrics = []
    for key, info in METRICS.items():
        audit = audits.get(info["lhId"]) or {}
        raw = audit.get("score")
        score = None if raw is None else round(raw * 100)
        b = band(score)
        metrics.append({
            "key": key, "label": info["label"], "name": info["name"],
            "value": audit.get("displayValue") or "n/a",
            "numeric": audit.get("numericValue"),
            "score": score, "level": b["level"], "emoji": b["emoji"], "rating": b["text"],
            "what": info["what"], "why": info["why"],
        })

    cats = lhr.get("categories", {}) or {}
    categories = []
    for k in CATEGORIES:
        if cats.get(k):
            score = round((cats[k].get("score") or 0) * 100)
            b = band(score)
            categories.append({"key": k, "label": cats[k].get("title"), "score": score,
                               "level": b["level"], "emoji": b["emoji"], "rating": b["text"]})

    perf = next((c for c in categories if c["key"] == "performance"), None)
    perf_score = perf["score"] if perf else None

    return {
        "url": url,
        "finalUrl": lhr.get("finalDisplayedUrl") or lhr.get("finalUrl") or url,
        "testedAt": lhr.get("fetchTime"),
        "performanceScore": perf_score,
        "verdict": verdict(perf_score),
        "categories": categories,
        "metrics": metrics,
        "opportunities": top_opportunities(lhr),
    }


def top_opportunities(lhr):
    """Lighthouse's own ranked suggestions, by estimated time saved."""
    opps = [
        a for a in lhr.get("audits", {}).values()
        if (a.get("details") or {}).get("type") == "opportunity"
        and (a["details"].get("overallSavingsMs") or 0) > 0
    ]
    opps.sort(key=lambda a: a["details"]["overallSavingsMs"], reverse=True)
    return [{"title": a["title"], "saveMs": round(a["details"]["overallSavingsMs"])} for a in opps[:6]]
